package com.appResource.acitivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;

import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import org.apache.http.protocol.HTTP;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ObjectNode;
import org.codehaus.jackson.node.TextNode;

import com.appResource.acitivity.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;

public class AppActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login);
	}

	@SuppressWarnings("deprecation")
	public void submitInfo(View v) throws MalformedURLException {
		// System.out.println("-----------+++++++++++++");
		String name = "";
		String mobilephone = "";
		String server = "";
		String storage = "";
		String usage = "";
		EditText editName = (EditText) findViewById(R.id.EditName);
		EditText editMobilePhone = (EditText) findViewById(R.id.EditMobilePhone);
		EditText editServer = (EditText) findViewById(R.id.EditServer);
		EditText editStorage = (EditText) findViewById(R.id.EditStorage);
		EditText editUsage = (EditText) findViewById(R.id.EditUsage);
		name = editName.getText().toString();
		mobilephone = editMobilePhone.getText().toString();
		server = editServer.getText().toString();
		storage = editStorage.getText().toString();
		usage = editUsage.getText().toString();
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String timedate = sdf.format(d);
		System.out.println("The date is : " + timedate);

		String newDoc = "{ \"name\":\"" + name + "\",\"mobilephone\":\""
				+ mobilephone + "\",\"server\":\"" + server
				+ "\",\"storage\":\"" + storage + "\",\"usage\":\"" + usage
				+ "\",\"timedata\":\"" + timedate + "\",\"tag\":\"appInuput\"}";

		System.out.println(newDoc);
		String user, db, pass, baseUrl;
		HashMap<String, String> map = getCloudantMap();
		user = map.get("user");
		pass = map.get("pass");
		db = "iicsupport";

		baseUrl = "https://" + user + ":" + pass + "@" + user
				+ ".cloudant.com/" + db + "/";

		DefaultHttpClient httpClient = new DefaultHttpClient();

		// System.out.println(baseUrl);
		HttpPost httpPost = new HttpPost(baseUrl);
		// System.out.println(newDoc);

		StringEntity entity = null;
		try {
			entity = new StringEntity(newDoc, HTTP.UTF_8);
		} catch (UnsupportedEncodingException e1) {

			e1.printStackTrace();
		}
		entity.setContentType("application/json");
		httpPost.setEntity(entity);

		String encodedUserPass = new String(
				Base64.encodeBase64((user + ":" + pass).getBytes()));
		httpPost.setHeader("Authorization", "Basic " + encodedUserPass);
		String id = "";
		boolean a = true;
		try {

			HttpResponse postResp = httpClient.execute(httpPost);

			InputStream is = postResp.getEntity().getContent();
			ObjectMapper mapper = new ObjectMapper();
			ObjectNode postRespDoc = mapper.readValue(is, ObjectNode.class);
			id = ((TextNode) postRespDoc.get("id")).getTextValue();
			System.out.println("The new document's ID is " + id + ".");

			ObjectNode doc = read("iicsupport_constant", baseUrl, user, pass);

			// update the doc and then commit to the database
			doc.put("main_id", id);
			doc.put("flag", "1");
			String rev = update(doc, baseUrl, user, pass);
		} catch (IOException e) {
			System.out
					.println("An error occurred while creating a new document.");
			System.out.println(e.getMessage());
		}

		if (id == "")
			a = false;
		String mess = "";

		if (a) {
			mess = "  Successful. If you want to sumbit another form, please click YES. if not, please click NO.";
		} else
			mess = "  Error! Please check and click Yes to resumbit the form, click NO to exit.";
		AlertDialog.Builder dialog = new AlertDialog.Builder(AppActivity.this);
		dialog.setTitle("messages")
				.setIcon(android.R.drawable.ic_dialog_info)
				.setMessage(mess)
				.setPositiveButton("YES",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {

								EditText editName = (EditText) findViewById(R.id.EditName);
								editName.setText("");
								EditText editMobilePhone = (EditText) findViewById(R.id.EditMobilePhone);
								editMobilePhone.setText("");
								EditText editServer = (EditText) findViewById(R.id.EditServer);
								editServer.setText("");
								EditText editStorage = (EditText) findViewById(R.id.EditStorage);
								editStorage.setText("");
								EditText editUsage = (EditText) findViewById(R.id.EditUsage);
								editUsage.setText("");
							}
						})
				.setNegativeButton("NO", new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int which) {

						AppActivity.this.finish();

					}
				}).create().show();

	}

	// Read a document
	private static ObjectNode read(String id, String baseUrl, String user,
			String pass) {
		// initialize the GET with the base URL and the document ID
		HttpGet httpGet = new HttpGet(baseUrl + id);
		DefaultHttpClient httpClient = new DefaultHttpClient();
		ObjectMapper mapper = new ObjectMapper();

		String encodedUserPass = new String(
				Base64.encodeBase64((user + ":" + pass).getBytes()));
		httpGet.setHeader("Authorization", "Basic " + encodedUserPass);

		// initialize the document we want to return
		ObjectNode doc = null;

		try {
			// send the request and read the response
			HttpResponse getResp = httpClient.execute(httpGet);
			doc = mapper.readValue(getResp.getEntity().getContent(),
					ObjectNode.class);
			String rev = ((TextNode) doc.get("_rev")).getTextValue();
			String flag = ((TextNode) doc.get("flag")).getTextValue();
			String main_id = ((TextNode) doc.get("main_id")).getTextValue();

			System.out.println("flag===========" + flag);
			System.out.println("main_id==============" + main_id);
			// httpGet.releaseConnection();
			System.out.println("The revision after this read request is " + rev
					+ ".");
		} catch (IOException e) {
			System.out.println("An error occurred while reading a document.");
			System.out.println(e.getMessage());
		}
		// return the read doc
		return doc;
	}

	// Update a document
	@SuppressWarnings("deprecation")
	private static String update(ObjectNode doc, String baseUrl, String user,
			String pass) {
		// pull the id from the document. We'll need that for the PUT request
		String id = ((TextNode) doc.get("_id")).getTextValue();

		// initialize the PUT with the base URL and the document ID
		HttpPut httpPut = new HttpPut(baseUrl + id);

		// add your credentials to the request
		DefaultHttpClient httpClient = new DefaultHttpClient();
		ObjectMapper mapper = new ObjectMapper();

		String encodedUserPass = new String(
				Base64.encodeBase64((user + ":" + pass).getBytes()));
		httpPut.setHeader("Authorization", "Basic " + encodedUserPass);
		// initialize the rev we want to return
		String rev = "";

		// convert the doc back to a StringEntity
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		StringEntity entity = null;
		try {
			mapper.writeValue(baos, doc);
			entity = new StringEntity(baos.toString(), HTTP.UTF_8);
		} catch (IOException e1) {

			e1.printStackTrace();
		}
		entity.setContentType("application/json");
		httpPut.setEntity(entity);

		try {

			// send the request and read the response
			HttpResponse putResp = httpClient.execute(httpPut);
			ObjectNode putRespDoc = mapper.readValue(putResp.getEntity()
					.getContent(), ObjectNode.class);
			rev = ((TextNode) putRespDoc.get("rev")).getTextValue();
			System.out.println("The revision after the update request is "
					+ rev + ".");
		} catch (IOException e) {
			System.out.println("An error occurred while updating a document.");
			System.out.println(e.getMessage());
		}
		// return the rev of the updated doc
		return rev;
	}
	
	public HashMap<String, String> getCloudantMap() {
		String filename = "cloudant.properties";
		Properties prop = new Properties();
		HashMap<String, String> map = new HashMap<String, String>();
		try {
			prop.load(getClass().getResourceAsStream(filename));
			String user = prop.getProperty("user");
			String pass = prop.getProperty("pass");
			map.put("user", user);
			map.put("pass", pass);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}
}